/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cjwgr5moviereviews;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

/**
 *
 * @author Christopher
 */
public class ReviewSearcher {
    private String url = "https://api.nytimes.com/svc/movies/v2/reviews/search.json";
    private final String charset = "UTF-8";  
    private final String apiKey = "aac399e8db25423d9dcdbffd9d140d1d";


    public String searchForMovieTitle(String title)  {
        String json = "";
         try {
            String query = String.format("api-key=%s&query=%s", 
            URLEncoder.encode(apiKey, charset), 
            URLEncoder.encode(title, charset));
       
            URLConnection connection = new URL(url + "?" + query).openConnection();
            connection.setRequestProperty("Accept-Charset", charset);
            InputStream response = connection.getInputStream();
          
             try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(response))) {
                 
                 String line = null;
                 while((line = bufferedReader.readLine()) != null) {
                     json += line;
                 }
             } 
        }
        catch(Exception ex) {
            System.out.println("Exception: " + ex);
        }
         return json;
    }
}
