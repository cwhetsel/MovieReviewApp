/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cjwgr5moviereviews;


import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 *
 * @author Christopher
 */
public class MovieReviewsFXMLController implements Initializable {
    
    @FXML
    private Label title;
    @FXML
    private Label author;
    @FXML
    private Label summary;
    @FXML
    private Label rating;
    @FXML
    private Label opening;
    @FXML
    private Label headline;
    @FXML 
    private Label error;
    @FXML 
    private Button searchButton;
    @FXML
    private TextField searchBar;
    @FXML
    private ImageView image;
    
    private Stage stage; 
    
    private ReviewSearcher searcher; 
    private MovieReview review;
    private Image defaultImage;
    private final String src = "http://dailyrunneronline.com/wp-content/uploads/2014/02/o-THEATER-SEATS-facebook.jpg";
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        String query = searchBar.getText();
        String result = searcher.searchForMovieTitle("'" + query + "'");
        if(!review.initFromJsonString(result)) {
            error.setText("No results found for your Search");
        }
        else {
            error.setText("");
        }
        fillLabels(); 
    }
    @FXML 
    private void handleFullReviewButtonPress() {

        Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
        if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) {
            try {
              desktop.browse(new URL(review.getLink()).toURI());
             } catch (URISyntaxException | IOException e) {
                error.setText("Cannot open full review. " + e );
            }
        }
        else {
            error.setText("Desktop not supported for browse function");
        }
    }
    public void fillLabels() {
        author.setText(review.getAuthor());
        title.setText(review.getTitle());
        summary.setText(review.getSummary());
        rating.setText(review.getRating());
        opening.setText(review.getDate());
        headline.setText(review.getHeadline());
        setImage();
        
    }
    
    private void setImage() {
        if(review.getMediaSrc() != null && !review.getMediaSrc().equals("") ) {
            image.setImage(new Image(review.getMediaSrc(), review.getWidth(), review.getHeight(), false, false));
        }
        else {
            image.setImage(defaultImage);
        }
    }
    public void ready(Stage stage) {
        searcher = new ReviewSearcher(); 
        review = new MovieReview();
        defaultImage = new Image(src, 150, 125, false, false);

    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
