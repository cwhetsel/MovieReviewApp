/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cjwgr5moviereviews;

import org.json.simple.*;

/**
 *
 * @author Christopher
 */
public class MovieReview {
    private String title;
    private String summary; 
    private String rating; 
    private String link; 
    private String author;
    private String openingDate; 
    private String headline;
    private String linkText;
    private String mediaType; 
    private String mediaSrc; 
    private Long width; 
    private Long height; 
    
    
    
    public boolean initFromJsonString(String jsonString) {
        
        
        
        if (jsonString == null || jsonString.equals("")) return false;
        
        JSONObject jsonObj;
        JSONObject movie;
        JSONArray results;
        JSONObject jsonLink, multimedia; 
        try {
            jsonObj = (JSONObject)JSONValue.parse(jsonString);
            if(0 == (Long)jsonObj.get("num_results")) {
                return false;
            }
            results = (JSONArray)jsonObj.get("results");
            movie = (JSONObject)results.get(0);
            jsonLink = (JSONObject)movie.get("link");
            multimedia = (JSONObject)movie.get("multimedia"); 
            
            
            
            
        } catch (Exception ex) {
            System.out.println("Exception creating JSONObject");
            return false;
        }
        
        title = "";
        summary = "";
        rating = "";
        link = "";
        author = "";
        openingDate = "";
        headline = "";
        linkText = "";

        //this is bad because you are casting it to a string no matter what it is. COuld be badly formed json and will crash the program. 
        //really should put this into a try catch block. If anything is wron gyo ushould say this record is bad 
        try {
            title = (String)movie.getOrDefault("display_title", "");
            rating = (String)movie.getOrDefault("mpaa_rating", "");
            author = (String)movie.getOrDefault("byline", "");
            summary = (String)movie.getOrDefault("summary_short", "");
            headline = (String)movie.getOrDefault("headline", "");
            openingDate = (String)movie.getOrDefault("opening_date", "");
            
            if(link != null) {
                link = (String)jsonLink.getOrDefault("url", "");
                linkText = (String)jsonLink.getOrDefault("suggested_link_text", "");
            }
            
            if(multimedia != null) {
                height = (Long)multimedia.getOrDefault("height", 0);
                width = (Long)multimedia.getOrDefault("width", 0);
                mediaSrc = (String)multimedia.getOrDefault("src", "");
                 mediaType = (String)multimedia.getOrDefault("type", "");
            }
            else {
                mediaSrc = "";
            }
        }
        catch(Exception ex) {
            System.out.println("Exception parsing JSON. Bad record" + ex); 
        }
        return true;
    }
    @Override
    public String toString() {
        return String.format("%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %d, %d",
                title, rating, openingDate, headline, author, summary, link, linkText, mediaSrc, mediaType, height, width);
    } 
    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }
    public String getDate() {
        return openingDate;
    }
    public String getSummary() {
        return summary;
    }
    public String getRating() {
        return rating;
    }
    public String getLink() {
        return link;
    }
    public String getLinkText() {
        return linkText;
    }
    public String getHeadline() {
        return headline;
    }
    public String getMediaSrc() {
        return mediaSrc;
    }
    public String getMediaType() {
        return mediaType; 
    }
    public Long getHeight() {
        return height; 
    }
    public Long getWidth() {
        return width; 
    }
}

/*
{
  "status": "OK",
  "copyright": "Copyright (c) 2017 The New York Times Company. All Rights Reserved.",
  "has_more": false,
  "num_results": 1,
  "results": [
    {
      "display_title": "La La Land",
      "mpaa_rating": "PG-13",
      "critics_pick": 1,
      "byline": "A. O. SCOTT",
      "headline": "Review: Ryan Gosling and Emma Stone Aswirl in Tra La La Land",
      "summary_short": "Ms. Stone and Mr. Gosling sing and dance their way to art and love in Damien Chazelle’s new movie.",
      "publication_date": "2016-12-08",
      "opening_date": "2016-12-16",
      "date_updated": "2017-01-08 17:44:01",
      "link": {
        "type": "article",
        "url": "http://www.nytimes.com/2016/12/08/movies/la-la-land-review-ryan-gosling-emma-stone.html",
        "suggested_link_text": "Read the New York Times Review of La La Land"
      },
      "multimedia": {
        "type": "mediumThreeByTwo210",
        "src": "https://static01.nyt.com/images/2016/12/09/arts/9WEEKENDARTS1COVER1/9WEEKENDARTS1COVER1-mediumThreeByTwo210-v3.jpg",
        "width": 210,
        "height": 140
      }
    }
  ]
}
*/